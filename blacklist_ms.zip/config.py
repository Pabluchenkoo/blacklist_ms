from pydantic import BaseSettings
from dotenv import load_dotenv
import os

load_dotenv()  

class Settings(BaseSettings):
    SECRET_KEY: str = os.getenv('SECRET_KEY','your-secret-key')
    DATABASE_URL: str = os.getenv('DATABASE_URL', 'postgresql+asyncpg://postgres:password@database-1.chi2qeoo0z9n.us-east-1.rds.amazonaws.com:5432/blacklist_db')
    JWT_SECRET_KEY: str = os.getenv('JWT_SECRET_KEY', 'your-jwt-secret-key')

    class Config:
        env_file = ".env"

settings = Settings()
